Mandelbulb3D SE for Windows x64
Version 2.0.4

Extract the ZIP, then open Mandelbulb3D SE.exe.
INSTALLING MAPS
1. Open the app and click Open Map Folder in the main window.
2. Open the supplied M3Maps folder in another File Explorer window.
3. Copy its map files and any subfolders into the folder opened by the app.
   Copy the contents, rather than nesting another M3Maps folder inside it.
4. Quit and reopen the app if the new maps are not shown.

Keep LICENSE and Licenses with the app. This is an unsigned Windows beta build.
Source: https://github.com/Rodrigo-Spacecraft/Mandelbulb3D-SE
Support: https://greenoak-software.com/m3dse_support.html
